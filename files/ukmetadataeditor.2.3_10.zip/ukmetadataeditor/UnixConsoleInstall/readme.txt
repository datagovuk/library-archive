Edit the auto-install.xml file to specify the intended install location.
To use, push your geonetwork install file and the auto-install.xml file up to the server.
Issue the following command on the server:

java -jar geonetwork-install-W.X.Y-Z.jar auto-install.xml

