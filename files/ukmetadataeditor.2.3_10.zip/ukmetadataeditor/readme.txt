Abstract
========
This is the install and customise tool for the UK Metadata Editor.

You will require a clean GeoNetwork install of version 2.6.x.

Please start with Documents/UK Metadata Editor customisation for GeoNetwork.doc